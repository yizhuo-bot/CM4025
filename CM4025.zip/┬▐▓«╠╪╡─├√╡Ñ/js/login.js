$('.form .submit').off('click').on('click',function() {
	if ($('#username').val() === 'testuser' && $('#password').val() === 'password123') {
		alert('login successfully！')
		location.href = 'index.html?type=1'
	}else {
		alert('account or password is error!')
	}
})