$('.form .submit').off('click').on('click', function() {
	if ($('#name').val() && $('#password').val() && $('#username').val() && $('#email').val() && $('#sex')
	.val() && $('#phone-number').val()) {
		alert('registered successfully！')
		location.href = 'index.html'
	} else {
		alert('Imperfect information!')
	}
})

// $('#profession').bind('input propertychange', function() {
// 	console.log($(this).val());
// 	if ($(this).val() === 'front-end')


// })
// 

$("#profession").change(function() {
	console.log($(this).val());
		if ($(this).val() === 'front-end engineer') {
			$('.front-end').show()
			$('.back-end').hide()
		} else if ($(this).val() === 'back-end engineer') {
			$('.front-end').hide()
			$('.back-end').show()
		}
});
